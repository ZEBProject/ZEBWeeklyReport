//
//  SecondViewController.m
//  WZLDemoCollection
//
//  Created by wengzilin on 16/3/25.
//  Copyright © 2016年 wengzilin. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()
@property (strong, nonatomic) IBOutlet UIButton *shareBtn;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"DetailViewController";
}

- (IBAction)onShareBtnPressed:(id)sender
{
    
}

@end
