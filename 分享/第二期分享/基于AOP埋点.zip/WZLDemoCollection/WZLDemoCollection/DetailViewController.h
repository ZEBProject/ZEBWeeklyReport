//
//  SecondViewController.h
//  WZLDemoCollection
//
//  Created by wengzilin on 16/3/25.
//  Copyright © 2016年 wengzilin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@end
