//
//  WEventIDConstant.h
//  WZLDemoCollection
//
//  Created by wengzilin on 16/4/1.
//  Copyright © 2016年 wengzilin. All rights reserved.
//

#ifndef WEventIDConstant_h
#define WEventIDConstant_h

#define EVENT_HOME_ENTER_PAGE       @"EVENT_HOME_ENTER_PAGE"
#define EVENT_HOME_LEAVE_PAGE       @"EVENT_HOME_LEAVE_PAGE"
#define EVENT_HOME_FAV              @"EVENT_HOME_FAV"
#define EVENT_HOME_SHARE            @"EVENT_HOME_SHARE"

#define EVENT_DETAIL_ENTER_PAGE     @"EVENT_DETAIL_ENTER_PAGE"
#define EVENT_DETAIL_LEAVE_PAGE     @"EVENT_DETAIL_LEAVE_PAGE"
#define EVENT_DETAIL_SHARE          @"EVENT_DETAIL_SHARE"


#endif /* WEventIDConstant_h */
