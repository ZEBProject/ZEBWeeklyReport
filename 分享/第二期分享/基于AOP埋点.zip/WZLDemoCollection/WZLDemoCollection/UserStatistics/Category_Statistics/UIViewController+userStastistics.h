//
//  UIViewController+userStastistics.h
//  WuJieCaoJoke
//
//  Created by wzl on 15-8-9.
//  Copyright (c) 2015年 Weng Zilin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (userStastistics)

@end
