//
//  CountingOperation.m
//  demo
//
//  Created by 向志刚 on 2017/11/20.
//  Copyright © 2017年 向志刚. All rights reserved.
//

#import "CountingOperation.h"

@implementation CountingOperation

NSUInteger startingCount;
NSUInteger endingCount;
BOOL finished;
BOOL executing;

- (id) init {
    
    return([self initWithStartingCount:0 endingCount:1000]);
    
}

// 我们为我们自定义的operation，提供的初始化方法。这个初始化方法，根据我们的需要进行自定义
- (id) initWithStartingCount:(NSUInteger)paramStartingCount endingCount:(NSUInteger)paramEndingCount{
    self = [super init];
    if (self != nil){
        // 用参数的方式，初始化我们需要的数据，将在main中使用
        startingCount = paramStartingCount;
        endingCount = paramEndingCount;
    }
    return(self);
}

- (void) start {
    // 如果我们取消了在开始之前，我们就立即返回并生成所需的KVO通知
    if ([self isCancelled]){
        // 我们取消了该 operation，那么就要告诉KVO，该operation已经执行完成（isFinished）。这样，调用的队列（或者线程）会继续执行。
        [self willChangeValueForKey:@"isFinished"];
        finished = YES;
        [self didChangeValueForKey:@"isFinished"];
        
        return;
    } else {
        // 没有取消，那就要告诉KVO，该队列开始执行了（isExecuting）！那么，就会调用main方法，进行同步执行。
        [self willChangeValueForKey:@"isExecuting"];
        executing = YES;
        [self main];// 执行main方法
        [self didChangeValueForKey:@"isExecuting"];
    }
}

- (void) main {
    @try {
        // 我们必须为我们自定义的operation 提供 autorelease pool,因为 operation 完成后需要销毁。
        @autoreleasepool {
            // 提供一个变量标识，来表示我们需要执行的操作是否完成了，当然，没开始执行之前，为NO
            BOOL taskIsFinished = NO;
            // while 保证：只有当没有执行完成和没有被取消，才执行我们自定义的相应操作
            while (taskIsFinished == NO &&[self isCancelled] == NO){
                
                // 我们自定义的操作
                
                NSLog(@"Main Thread = %@", [NSThread mainThread]);
                NSLog(@"Current Thread = %@", [NSThread currentThread]);
                
                // 使用我们初始化传递来的参数：startingCount，endingCount。
                NSUInteger counter = startingCount;
                for (counter = startingCount;counter < endingCount;counter++){
                    
                    NSLog(@"Count = %lu", (unsigned long)counter);
                }
                // 这里，设置我们相应的操作都已经完成，后面就是要通知KVO我们的操作完成了。
                
                taskIsFinished = YES;
            }
            // KVO 生成通知，告诉其他线程，该operation 执行完了
            [self willChangeValueForKey:@"isFinished"];
            [self willChangeValueForKey:@"isExecuting"];
            finished = YES;
            executing = NO;
            [self didChangeValueForKey:@"isFinished"];
            [self didChangeValueForKey:@"isExecuting"];
            
        }
    }
    @catch (NSException * e) {
        NSLog(@"Exception %@", e);
    }
}

// 返回该operation是否完成
- (BOOL) isFinished{
    return(finished);
}

// 返回该operation是否在执行
- (BOOL) isExecuting{
    return(executing);
}

// 1.使用自己定义的同步operation，需要继承自NSOperation，并实现必要的方法：isFinished，isExecuting，main等，并实现KVO机制
// 2.如果不想让你自定义的operation与其他operation进行异步操作,你可以手动开始（调用start方法），并且在operation的start方法里面简单的调用main方法。
// 3.如果要自定义operation,需要继承资NSOperation。并且重载 isExecuting方法和isFinished方法。在这两个方法中,必须返回一个线程安全值（通常是个BOOL值）,这个值可以在 operation 中进行操作。
// 4.一旦你的 operation 开始了,必须通过 KVO,告诉所有的监听者,现在该operation的执行状态。
// 5.在 operation 的 main 方法里面,必须提供 autorelease pool,因为你的 operation 完成后需要销毁。
// 6.必须为我们自定义的 operation 提供一个初始化方法。如：initWithStartingCount 方法。

@end
