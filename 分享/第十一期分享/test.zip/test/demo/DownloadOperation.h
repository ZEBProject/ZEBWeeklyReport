//
//  DownloadOperation.h
//  demo
//
//  Created by 向志刚 on 2017/11/14.
//  Copyright © 2017年 向志刚. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UIKit/UIKit.h"

@protocol DownloadOperationDelegate;

@interface DownloadOperation : NSOperation

// 图片的url路径
@property (nonatomic, copy) NSString *imageUrl;
// 代理
@property (nonatomic, assign) id<DownloadOperationDelegate> delegate;

- (id)initWithUrl:(NSString *)url delegate:(id<DownloadOperationDelegate>)delegate;

@end

// 图片下载的协议
@protocol DownloadOperationDelegate <NSObject>

- (void)downloadFinishWithImage:(UIImage *)image;

@end
