//
//  CountingOperation.h
//  demo
//
//  Created by 向志刚 on 2017/11/20.
//  Copyright © 2017年 向志刚. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CountingOperation : NSOperation

- (id) initWithStartingCount:(NSUInteger)paramStartingCount endingCount:(NSUInteger)paramEndingCount;

@end
