//
//  ViewController.m
//  音频的后台播放
//
//  Created by 向志刚 on 2017/9/19.
//  Copyright © 2017年 PA. All rights reserved.
//


//模拟器退出后台还是继续运行的

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
