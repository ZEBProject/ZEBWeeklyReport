//
//  ViewController.m
//  NSTimer问题
//
//  Created by 向志刚 on 2017/9/20.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSTimer *timer; // timer
@property(nonatomic,assign)int countDown; // 倒数计时用
@property(nonatomic,strong)NSDate *beforeDate; // 上次进入后台时间
@property(nonatomic,strong)UITableView *tableView; // tableView
@end

static NSString * const tableViewCellId = @"tableViewCellId";
static int const tick = 60;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"简单的倒计时Demo";
    [self setup];
    [self setupNotification];
    [self startCountDown]; // 假装点击了按钮，开始计时
    
}

-(void)viewDidDisappear:(BOOL)animated {
    [self viewDidDisappear:animated];
    [self stopTimer]; // 离开viewController后销毁定时器,否则self被NSTimer强引用无法释放，当然也就轮不到dealloc执行了
}

-(void)dealloc {
    
    _tableView.delegate = nil;
    _tableView.dataSource = nil;
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationWillEnterForegroundNotification object:nil];
    
    [self stopTimer]; // 如果没有在合适的地方销毁定时器就会内存泄漏啦，delloc也不可能执行。正确的销毁定时器这里可以不用写这个方法了，这里只是提个醒
}

-(void)setup {
    // tableView
    _tableView = [[UITableView alloc]initWithFrame:self.view.frame style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor whiteColor];
    _tableView.rowHeight = 44;
    [self.view addSubview:_tableView];
    
}

-(void)setupNotification {
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(enterBG) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(enterFG) name:UIApplicationWillEnterForegroundNotification object:nil];
}

#pragma mark - method area

/**
 *  进入后台记录当前时间
 */
-(void)enterBG {
    NSLog(@"应用进入后台啦");
    _beforeDate = [NSDate date];
}

/**
 *  返回前台时更新倒计时值
 */
-(void)enterFG {
    NSLog(@"应用将要进入到前台");
    NSDate * now = [NSDate date];
    int interval = (int)ceil([now timeIntervalSinceDate:_beforeDate]);
    int val = _countDown - interval;
    if(val > 1){
        _countDown -= interval;
    }else{
        _countDown = 1;
    }
}

/**
 *  开始倒计时
 */
-(void)startCountDown {
    
    _countDown = tick; // 重置计时
    
//    _timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(timerFired:) userInfo:nil repeats:YES]; // 需要加入手动RunLoop，需要注意的是在NSTimer工作期间self是被强引用的
    _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0) target:self selector:@selector(timerFired:) userInfo:nil repeats:YES];

//    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes]; // 使用NSRunLoopCommonModes才能保证RunLoop切换模式时，NSTimer能正常工作。
}

/**
 *  停止倒计时
 *  别小看销毁定时器，没用好可就内存泄漏咯
 */
- (void)stopTimer {
    if (_timer) {
        [_timer invalidate];
    }
}

/**
 *  倒计时逻辑
 */
-(void)timerFired:(NSTimer *)timer {
    
    switch (_countDown) {
        case 1:
            NSLog(@"重新发送");
            
            [self stopTimer];
            break;
        default:
            _countDown -=1;
            NSLog(@"倒计时中：%d",_countDown);
            break;
    }
}

#pragma mark - tableView delegate
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:tableViewCellId];
    if(!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tableViewCellId];
        cell.textLabel.text = @"测试用";
    }
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    NSLog(@"tableView滑动咯");
}

@end
