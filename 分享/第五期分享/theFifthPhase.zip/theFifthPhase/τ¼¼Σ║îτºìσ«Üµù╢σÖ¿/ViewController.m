//
//  ViewController.m
//  第二种定时器
//
//  Created by 向志刚 on 2017/9/19.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, assign) int i;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _i = 0;
    _label = [[UILabel alloc] initWithFrame:CGRectMake(100,100 , 100, 100)];
    _label.backgroundColor = [UIColor greenColor];
    _label.textColor = [UIColor redColor];
    [self.view addSubview:_label];
    [self startDisplayLink];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)startDisplayLink{
    
    /*
     CADisplayLink是一个能让我们以和屏幕刷新率同步的频率将特定的内容画到屏幕上的定时器类。 CADisplayLink以特定模式注册到runloop后， 每当屏幕显示内容刷新结束的时候，runloop就会向 CADisplayLink指定的target发送一次指定的selector消息， CADisplayLink类对应的selector就会被调用一次。
     
     iOS设备的屏幕刷新频率是固定的，CADisplayLink在正常情况下会在每次刷新结束都被调用，精确度相当高。使用场合相对专一，适合做UI的不停重绘，比如自定义动画引擎或者视频播放的渲染。不需要在格外关心屏幕的刷新频率了，本身就是跟屏幕刷新同步的。
     */
    
    self.displayLink = [CADisplayLink displayLinkWithTarget:self
                                                   selector:@selector(handleDisplayLink:)];
    [self.displayLink addToRunLoop:[NSRunLoop currentRunLoop]
                           forMode:NSDefaultRunLoopMode];
}

- (void)handleDisplayLink:(CADisplayLink *)displayLink{
    _label.text = [NSString stringWithFormat:@"%D",_i++];
}

- (void)stopDisplayLink{
    [self.displayLink invalidate];
    self.displayLink = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
