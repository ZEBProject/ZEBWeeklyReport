//
//  ViewController.m
//  第三种定时器
//
//  Created by 向志刚 on 2017/9/19.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "ViewController.h"
#import "JX_GCDTimerManager.h"

@interface ViewController ()

@property (nonatomic, strong) UILabel *but;
@property (nonatomic, assign) int i;

@end

static NSString * const myTimer = @"MyTimer";

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    _but = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    _but.backgroundColor = [UIColor greenColor];
    _but.textColor = [UIColor redColor];
    [self.view addSubview:_but];
    _i = 1000;
    __weak typeof(self) weakSelf = self;
    [[JX_GCDTimerManager sharedInstance] scheduledDispatchTimerWithName:myTimer timeInterval:1.0 queue:nil repeats:YES actionOption:AbandonPreviousAction action:^{
        [weakSelf doSomething];
    }];
}


- (void)doSomething{
    dispatch_sync(dispatch_get_main_queue(), ^{
            _but.text = [NSString stringWithFormat:@"%D",_i--];
    });
    NSLog(@"%@",[NSString stringWithFormat:@"%D",_i--]);
}

@end
