//
//  ViewController.m
//  第二种倒计时
//
//  Created by 向志刚 on 2017/9/19.
//  Copyright © 2017年 PingAn. All rights reserved.
//
//通过定时器

#import "ViewController.h"

@interface ViewController ()
{
    UIButton *btn;
    int timeDown; //60秒后重新获取验证码
    NSTimer *timer;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame=CGRectMake(10, 200, 300, 50);
    btn.backgroundColor=[UIColor cyanColor];
    [btn setBackgroundImage:[UIImage imageNamed:@"bg_send_validate_code.png"] forState:UIControlStateNormal];
    [btn setTitle:@"获取验证码" forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}


- (void)btnAction{
    
    timeDown = 59;
    [self handleTimer];
    timer = [NSTimer scheduledTimerWithTimeInterval:(1.0) target:self selector:@selector(handleTimer) userInfo:nil repeats:YES];
    
}

-(void)handleTimer
{
    
    if(timeDown>=0)
    {
        [btn setUserInteractionEnabled:NO];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        int sec = ((timeDown%(24*3600))%3600)%60;
        [btn setTitle:[NSString stringWithFormat:@"(%d)重发验证码",sec] forState:UIControlStateNormal];
        
    }
    else
    {
        [btn setUserInteractionEnabled:YES];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [btn setTitle:@"重发验证码" forState:UIControlStateNormal];
        
        [timer invalidate];
        
    }
    timeDown = timeDown - 1;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
