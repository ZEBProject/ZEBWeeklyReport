//
//  main.m
//  第二种倒计时
//
//  Created by 向志刚 on 2017/9/19.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
