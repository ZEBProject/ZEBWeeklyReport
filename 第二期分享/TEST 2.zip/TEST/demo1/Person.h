//
//  Person.h
//  TEST
//
//  Created by 向志刚 on 2017/9/11.
//  Copyright © 2017年 向志刚(外包). All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, assign) NSInteger age;

@end
