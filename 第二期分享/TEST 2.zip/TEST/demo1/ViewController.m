//
//  ViewController.m
//  demo1
//
//  Created by 向志刚 on 2017/9/6.
//  Copyright © 2017年 向志刚(外包). All rights reserved.
//

#import "ViewController.h"
#import "Person.h"

#ifdef DEBUG
# define DLog(format, ...) NSLog((@"[文件名:%s]" "[函数名:%s]" "[行号:%d]" format), __FILE__, __FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
# define DLog(...);
#endif

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSArray *array= [NSArray arrayWithObjects:@"2.0",@"2.3",@"3.0",@"4.0",@"10",nil];
    
    CGFloat sum = [[array valueForKeyPath:@"@sum.floatValue"] floatValue];
    
    CGFloat avg = [[array valueForKeyPath:@"@avg.floatValue"] floatValue];
    
    CGFloat max = [[array valueForKeyPath:@"@max.floatValue"] floatValue];
    
    CGFloat min = [[array valueForKeyPath:@"@min.floatValue"] floatValue];
    
    DLog(@"%f---%f---%f---%f",sum,avg,max,min);

    Person *one = [[Person alloc] init];
    Person *two = [[Person alloc] init];
    Person *three = [[Person alloc] init];
    Person *four = [[Person alloc] init];

    one.name = @"七两";
    two.name = @"阿刚";
    three.name = @"亮亮";
    four.name = @"test";
    
    one.age = 25;
    two.age = 24;
    three.age = 23;
    four.age = 20;

    NSArray *personArray= [NSArray arrayWithObjects:one,two,three,four,nil];
    
    CGFloat ageAvg = [[personArray valueForKeyPath:@"@avg.age"] integerValue];
    CGFloat ageMax = [[personArray valueForKeyPath:@"@max.age"] integerValue];
    CGFloat ageMin = [[personArray valueForKeyPath:@"@min.age"] integerValue];
    
    DLog(@"%f---%f---%f",ageAvg,ageMax,ageMin);
    
    //定义谓词对象,谓词对象中包含了过滤条件
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name = 'test' && age < 24"];

    //使用谓词条件过滤数组中的元素,过滤之后返回查询的结果
    NSArray *ageArr = [personArray filteredArrayUsingPredicate:predicate];
    for (Person *per in ageArr) {
        NSLog(@" age < 24 --> %@, %ld", per.name, per.age);
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
