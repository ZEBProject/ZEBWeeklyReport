//
//  AppDelegate.h
//  demo2
//
//  Created by 向志刚 on 2017/9/6.
//  Copyright © 2017年 向志刚(外包). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

