//
//  ViewController.m
//  demo2
//
//  Created by 向志刚 on 2017/9/6.
//  Copyright © 2017年 向志刚(外包). All rights reserved.
//

#import "ViewController.h"
#import <objc/runtime.h>
#import "UIViewController+Tracking.h"

@interface ViewController ()

//剩余票数
@property(nonatomic,assign) int leftTicketsCount;
@property(nonatomic,strong)NSThread *thread1;
@property(nonatomic,strong)NSThread *thread2;
@property(nonatomic,strong)NSThread *thread3;

@end

@implementation ViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [UIViewController load];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [UIViewController load];
}

-(void)viewDidLoad {
    [super viewDidLoad];
    //默认有20张票
    self.leftTicketsCount = 10;
    //开启多个线程，模拟售票员售票
    self.thread1 = [[NSThread alloc]initWithTarget:self selector:@selector(sellTickets) object:nil];
    self.thread1.name = @"售票员A";
    self.thread2 = [[NSThread alloc]initWithTarget:self selector:@selector(sellTickets) object:nil];
    self.thread2.name = @"售票员B";
    self.thread3 = [[NSThread alloc]initWithTarget:self selector:@selector(sellTickets) object:nil];
    self.thread3.name = @"售票员C";
    
}

-(void)sellTickets
{
    while (1) {
        //1.先检查票数
        int count = self.leftTicketsCount;
        if (count > 0) {
        //暂停一段时间
            [NSThread sleepForTimeInterval:0.002];
            
        //2.票数-1
            self.leftTicketsCount= count - 1;
            
        //获取当前线程
            NSThread *current=[NSThread currentThread];
            NSLog(@"%@--卖了一张票，还剩余%d张票",current,self.leftTicketsCount);
        }else
        {
            //退出线程
            [NSThread exit];
            }
    }
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    //开启线程
    
    [self.thread1 start];
    [self.thread2 start];
    [self.thread3 start];
}

@end
