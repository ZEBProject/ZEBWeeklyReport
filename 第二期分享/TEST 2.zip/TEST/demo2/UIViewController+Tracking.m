//
//  UIViewController+Tracking.m
//  TEST
//
//  Created by 向志刚 on 2017/9/11.
//  Copyright © 2017年 向志刚(外包). All rights reserved.
//

#import "UIViewController+Tracking.h"

@implementation UIViewController (Tracking)

+ (void)load {
    
    // 交换方法viewWillAppear：
    method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewWillAppear:)),class_getInstanceMethod(self, @selector(tracking_viewWillAppear:)));
    
    //交换方法viewWillDisappear：
    
    method_exchangeImplementations(class_getInstanceMethod(self, @selector(viewWillDisappear:)), class_getInstanceMethod(self, @selector(tracking_viewWillDisappear:)));
    
}

- (void)tracking_viewWillAppear:(BOOL)animated {
    
    [self tracking_viewWillAppear:animated];
    
    //此处添加你想统计的打点事件
    
    NSLog(@"当前viewController :%@",NSStringFromClass([self class]));
    
}

- (void)tracking_viewWillDisappear:(BOOL)animated {
    
    [self tracking_viewWillDisappear:animated];
    
    //此处添加你想统计的打点事件
    
    NSLog(@"当前viewController :%@",NSStringFromClass([self class]));
    
}

@end
